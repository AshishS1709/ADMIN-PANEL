import os
import sys

# Add parent directory to Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi import FastAPI
from chat.api import router as chat_router
from chat.database import engine
from chat.models import Base  # Make sure this import works

app = FastAPI(title="Chat Service API")

# Create database tables
Base.metadata.create_all(bind=engine)

# Include chat router
app.include_router(chat_router, prefix="/api", tags=["chat"])

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)