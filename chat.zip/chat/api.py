import os
import sys

# Add parent directory to Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi import APIRouter, HTTPException, Depends, File, UploadFile
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from typing import List, Optional
from pydantic import BaseModel
from chat.database import get_db  # Only import once
from chat.models import Message, Attachment, MessageType, MessageStatus

router = APIRouter()

# REMOVED: Duplicate get_db function - use the one from chat.database

class MessageCreate(BaseModel):
    message_type: MessageType
    status: MessageStatus
    sender_type: str
    sender_id: str
    recipient_type: str
    recipient_id: str
    content: str

class MessageFilter(BaseModel):
    message_type: Optional[MessageType] = None
    status: Optional[MessageStatus] = None
    sender_id: Optional[str] = None
    recipient_id: Optional[str] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None

class MessageResponse(BaseModel):
    id: int
    message_type: MessageType
    status: MessageStatus
    sender_type: str
    sender_id: str
    recipient_type: str
    recipient_id: str
    content: str
    created_at: datetime
    updated_at: datetime
    attachments: List[str] = []  # Default empty list
    
    class Config:
        from_attributes = True  # For Pydantic v2
        # orm_mode = True  # For Pydantic v1

@router.post("/messages", response_model=MessageResponse)
async def create_message(message: MessageCreate, db: Session = Depends(get_db)):
    try:
        # Use model_dump() for Pydantic v2, or dict() for v1
        db_message = Message(**message.model_dump())
        db.add(db_message)
        db.commit()
        db.refresh(db_message)
        
        # Create response with attachments
        response_data = {
            "id": db_message.id,
            "message_type": db_message.message_type,
            "status": db_message.status,
            "sender_type": db_message.sender_type,
            "sender_id": db_message.sender_id,
            "recipient_type": db_message.recipient_type,
            "recipient_id": db_message.recipient_id,
            "content": db_message.content,
            "created_at": db_message.created_at,
            "updated_at": db_message.updated_at,
            "attachments": []  # Empty for new messages
        }
        return response_data
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error creating message: {str(e)}")

@router.get("/api/messages", response_model=List[MessageResponse])
async def get_messages(
    message_type: Optional[str] = None,
    status: Optional[str] = None,
    sender_id: Optional[str] = None,
    recipient_id: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    db: Session = Depends(get_db)
):
    try:
        query = db.query(Message)
        
        # Apply filters
        if message_type:
            query = query.filter(Message.message_type == message_type)
        if status:
            query = query.filter(Message.status == status)
        if sender_id:
            query = query.filter(Message.sender_id == sender_id)
        if recipient_id:
            query = query.filter(Message.recipient_id == recipient_id)
        if start_date:
            start_dt = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
            query = query.filter(Message.created_at >= start_dt)
        if end_date:
            end_dt = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
            query = query.filter(Message.created_at <= end_dt)
        
        messages = query.order_by(Message.created_at.desc()).all()
        
        # Convert to response format
        response_messages = []
        for msg in messages:
            response_messages.append({
                "id": msg.id,
                "message_type": msg.message_type,
                "status": msg.status,
                "sender_type": msg.sender_type,
                "sender_id": msg.sender_id,
                "recipient_type": msg.recipient_type,
                "recipient_id": msg.recipient_id,
                "content": msg.content,
                "created_at": msg.created_at,
                "updated_at": msg.updated_at,
                "attachments": [a.file_path for a in getattr(msg, 'attachments', [])]
            })
        
        return response_messages
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching messages: {str(e)}")

@router.put("/api/messages/{message_id}/status")
async def update_message_status(
    message_id: int,
    status: str,  # Accept as string parameter
    db: Session = Depends(get_db)
):
    try:
        message = db.query(Message).filter(Message.id == message_id).first()
        if not message:
            raise HTTPException(status_code=404, detail="Message not found")
        
        # Update status (assuming MessageStatus is an enum)
        message.status = status
        message.updated_at = datetime.utcnow()
        db.commit()
        db.refresh(message)
        
        return {
            "id": message.id,
            "message_type": message.message_type,
            "status": message.status,
            "sender_type": message.sender_type,
            "sender_id": message.sender_id,
            "recipient_type": message.recipient_type,
            "recipient_id": message.recipient_id,
            "content": message.content,
            "created_at": message.created_at,
            "updated_at": message.updated_at,
            "attachments": [a.file_path for a in getattr(message, 'attachments', [])]
        }
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error updating message: {str(e)}")

@router.post("/api/messages/{message_id}/attachments")
async def upload_attachment(
    message_id: int,
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    try:
        message = db.query(Message).filter(Message.id == message_id).first()
        if not message:
            raise HTTPException(status_code=404, detail="Message not found")
        
        attachment = Attachment(
            message_id=message_id,
            file_path=file.filename,
            file_type=file.content_type,
            created_at=datetime.utcnow()
        )
        
        db.add(attachment)
        db.commit()
        db.refresh(attachment)
        
        return {"message": "Attachment uploaded successfully", "attachment_id": attachment.id}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error uploading attachment: {str(e)}")

@router.get("/api/messages/export")
async def export_messages(
    message_type: Optional[str] = None,
    status: Optional[str] = None,
    sender_id: Optional[str] = None,
    recipient_id: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    db: Session = Depends(get_db)
):
    try:
        # Get messages using the same logic as get_messages
        query = db.query(Message)
        
        # Apply filters
        if message_type:
            query = query.filter(Message.message_type == message_type)
        if status:
            query = query.filter(Message.status == status)
        if sender_id:
            query = query.filter(Message.sender_id == sender_id)
        if recipient_id:
            query = query.filter(Message.recipient_id == recipient_id)
        if start_date:
            start_dt = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
            query = query.filter(Message.created_at >= start_dt)
        if end_date:
            end_dt = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
            query = query.filter(Message.created_at <= end_dt)
        
        messages = query.order_by(Message.created_at.desc()).all()
        
        # Format data for export
        export_data = []
        for message in messages:
            export_data.append({
                "id": message.id,
                "message_type": message.message_type,
                "status": message.status,
                "sender": f"{message.sender_type}:{message.sender_id}",
                "recipient": f"{message.recipient_type}:{message.recipient_id}",
                "content": message.content,
                "created_at": message.created_at.isoformat(),
                "updated_at": message.updated_at.isoformat(),
                "attachments": [a.file_path for a in getattr(message, 'attachments', [])]
            })
        
        return {
            "messages": export_data,
            "total_count": len(messages),
            "exported_at": datetime.utcnow().isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error exporting messages: {str(e)}")

# Health check endpoint for testing
@router.get("/health")
async def health_check(db: Session = Depends(get_db)):
    try:
        # Test database connection
        db.execute("SELECT 1")
        return {"status": "healthy", "database": "connected"}
    except Exception as e:
        return {"status": "unhealthy", "database": str(e)}